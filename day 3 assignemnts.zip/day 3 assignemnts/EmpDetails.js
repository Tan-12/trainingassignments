
import React, { useState } from 'react';
 
function EmpDetails() {
    const [empsArray, setEmpsArray] = useState([]);
    const [empno, setEmpno] = useState("");
    const [ename, setEname] = useState("");
    const [job, setJob] = useState("");
    const [sal, setSal] = useState("");
    const [deptno, setDeptno] = useState("");
 
    function getDeptsButton_click() {
        let tempArray = [
            { empno: 10, ename: "Anushka", job: "QA Engineer", sal: 1000000, deptno: 101 },
            { empno: 20, ename: "Sravani", job: "Senior Analyst", sal: 1000000, deptno: 102 },
            { empno: 30, ename: "Karan", job: "Full Stack Developer", sal: 1000000, deptno: 103 },
        ];
        setEmpsArray(tempArray);
    }
 
    function addEmpButton_click() {
        let empObj = { empno, ename, job, sal, deptno };
        let tempArray = [...empsArray];
        tempArray.push(empObj);
        setEmpsArray(tempArray);
        clearFields();
    }
 
    function clearFields() {
        setEmpno("");
        setEname("");
        setJob("");
        setSal("");
        setDeptno("");
    }
 
    function deleteEmp_click(eno) {
        const confirmDelete = window.confirm('Are you sure you want to delete this employee?');
        if (confirmDelete) {
            let tempArray = [...empsArray];
            let index = tempArray.findIndex(item => item.empno === eno);
            tempArray.splice(index, 1);
            setEmpsArray(tempArray);
        }
    }
 
    function selectEmp_click(eno) {
        let empObj = empsArray.find(item => item.empno === eno);
        setEmpno(empObj.empno);
        setEname(empObj.ename);
        setJob(empObj.job);
        setSal(empObj.sal);
        setDeptno(empObj.deptno);
    }
 
    function updateEmpButton_click() {
        let tempArray = [...empsArray];
        let index = tempArray.findIndex(item => item.empno === empno);
        tempArray[index] = { empno, ename, job, sal, deptno };
        setEmpsArray(tempArray);
        clearFields();
    }
 
    let resultArray = empsArray.map((item, index) => (
        <tr key={index}>
            <td>{item.empno}</td>
            <td>{item.ename}</td>
            <td>{item.job}</td>
            <td>{item.sal}</td>
            <td>{item.deptno}</td>
            <td>
            <a  onClick={() => selectEmp_click(item.deptno)} href="javascript:void(0);">Select</a> |
                <button onClick={() => deleteEmp_click(item.empno)}>
                    <img src="https://www.pngmart.com/files/3/Delete-Button-PNG-Free-Download.png" width ="30"alt="Delete" />
                </button>
            </td>
        </tr>
    ));
 
    return (
        <>
            <input type="text" placeholder="Emp Number" value={empno} onChange={(e) => setEmpno(e.target.value)} />
            <input type="text" placeholder="Emp Name" value={ename} onChange={(e) => setEname(e.target.value)} />
            <input type="text" placeholder="Job" value={job} onChange={(e) => setJob(e.target.value)} />
            <input type="text" placeholder="Salary" value={sal} onChange={(e) => setSal(e.target.value)} />
            <input type="text" placeholder="Dept Number" value={deptno} onChange={(e) => setDeptno(e.target.value)} />
            <hr />
            <input type="button" onClick={getDeptsButton_click} value="Get Depts" />
            <input type="button" onClick={addEmpButton_click} value="Add Dept" />
            <input type="button" onClick={updateEmpButton_click} value="Update Dept" />
            <hr />
            <table border="2" width="500" cellspacing="0" cellpadding="5">
                <thead>
                    <tr>
                        <th>Emp Number</th>
                        <th>Emp Name</th>
                        <th>Job</th>
                        <th>Salary</th>
                        <th>Dept Number</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {resultArray}
                </tbody>
            </table>
        </>
    );
}
 
export default EmpDetails;
 