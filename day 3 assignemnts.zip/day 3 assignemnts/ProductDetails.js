import React, { useState } from 'react';

const ProductDetails = () => {
  const [productName, setProductName] = useState('');
  const [price, setPrice] = useState('');
  const [quantity, setQuantity] = useState('');
  const [totalAmount, setTotalAmount] = useState(0);

  const handleCalculateTotal = () => {
    let total = price * quantity;

    if (quantity >= 10 && quantity < 20) {
      total -= total * 0.05;
    } else if (quantity >= 20) {
      total -= total * 0.1;
    }

    if (quantity >= 10) {
      total -= 158;
    }

    setTotalAmount(total);
  };

  return (
    <div>
      <h2>Product Details</h2>
      <label>Product Name:</label>
      <input
        type="text"
        value={productName}
        onChange={(e) => setProductName(e.target.value)}
      />
      <br />
      <label>Price:</label>
      <input
        type="number"
        value={price}
        onChange={(e) => setPrice(parseFloat(e.target.value))}
      />
      <br />
      <label>Quantity:</label>
      <input
        type="number"
        value={quantity}
        onChange={(e) => setQuantity(parseInt(e.target.value))}
      />
      <br />
      <button onClick={handleCalculateTotal}>Calculate Total</button>
      <br />
      {totalAmount !== 0 && (
        <div>
          <h3>Total Amount: ${totalAmount.toFixed(2)}</h3>
        </div>
      )}
    </div>
  );
};

export default ProductDetails;

