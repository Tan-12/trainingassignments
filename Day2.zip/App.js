import React from 'react';
import ABC from './ABC';
import ImageArray from './ImageArray';
import Emp from './Emp';
function App() {

  

        let  file1 = "https://img.freepik.com/free-photo/green-park-view_1417-1492.jpg";

        let file2  = "images1.PNG";
        let file3  = "images2.PNG";
        let file4 = "images3.PNG";

  return (
      <>
      
      <ABC/>
        <h3>Working with Images React JS</h3>
        {/* <hr/>

        <img  width="100"  src="https://img.freepik.com/free-photo/green-park-view_1417-1492.jpg" />
        <br/>
        <img  width="100"  src={file1} />
        <hr/>

        <img  width="100"   src="./images/images1.PNG" />
        <img  width="100"   src="./images/Image2.jpg" />
        <hr/>

        <img  width="100"   src={ "./images/" + file2} />
        <hr/> */}
        <ImageArray/>
<Emp/>

        
       
       
       
      </>     
  );
}

export default App;
