import React from 'react';
 
function ImageArray() {
 
 
 
        let  imageArray = ["images1.PNG", "images2.PNG", "images3.PNG"];
       
        let resArray = imageArray.map(item => <img src={"./"+item} width="150"></img>);
 
 
  return (
      <>
        <h3>Working with Images using Arrays in React JS</h3>
        <hr/>
 
        {resArray}
 
      </>    
  );
}
 
export default ImageArray;
 

  
  
